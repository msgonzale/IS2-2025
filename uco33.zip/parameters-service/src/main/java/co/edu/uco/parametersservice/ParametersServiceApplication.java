package co.edu.uco.parametersservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParametersServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParametersServiceApplication.class, args);
	}

}

package co.edu.uco.ucochallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UcoChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
